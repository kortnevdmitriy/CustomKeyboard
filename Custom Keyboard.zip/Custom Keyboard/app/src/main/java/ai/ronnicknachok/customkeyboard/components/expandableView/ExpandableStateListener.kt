package ai.ronnicknachok.customkeyboard.components.expandableView

interface ExpandableStateListener {
	fun onStateChange(state: ExpandableState)
}