package ai.ronnicknachok.customkeyboard.components.expandableView

enum class ExpandableState {
	COLLAPSED,
	COLLAPSING,
	EXPANDED,
	EXPANDING
}